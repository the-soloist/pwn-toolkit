# copy from https://xuanxuanblingbling.github.io/ctf/tools/2021/01/10/bu/
def bu2fu(a):
    b = bin(a).replace("0b1", "0b0")
    e = int(b, 2) - pow(2, len(b) - 3)
    print("input         : " + hex(a))
    print("bin           : " + b[2:])
    print("signed        : " + str(e))
    print("signed hex    : " + hex(e))
    print("-" * (len(b) + 14))
    print("bit           : " + str(len(b) - 2))
    print("min signed    : " + str(hex(pow(2, len(b) - 3))) + ", -" + str(pow(2, len(b) - 3)))
    print("max signed    : " + str(hex(pow(2, len(b) - 3) - 1)) + ",  " + str(pow(2, len(b) - 3) - 1))
    print("max unsigned  : " + str(hex(pow(2, len(b) - 2) - 1)) + ",  " + str(pow(2, len(b) - 2) - 1))
    return e


def fu2bu(a, b):
    c = pow(2, b) + a
    print("input         : " + str(a))
    print("hex           : " + hex(c))
    print("bin           : " + bin(c)[2:])
    print("-" * (b + 16))
    print("bit           : " + str(b))
    print("min signed    : " + str(hex(pow(2, b - 1))) + ", -" + str(pow(2, b - 1)))
    print("max signed    : " + str(hex(pow(2, b - 1) - 1)) + ",  " + str(pow(2, b - 1) - 1))
    print("max unsigned  : " + str(hex(pow(2, b) - 1)) + ",  " + str(pow(2, b) - 1))
    return c


if __name__ == "__main__":
    fu2bu(-100, 32)
    print('\n\n')
    bu2fu(0xffffffffffffffff)
