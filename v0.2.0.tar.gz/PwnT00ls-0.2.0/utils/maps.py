#!/usr/bin/env python
# -*- coding: utf-8 -*-
import psutil
import sys
from pwn import gdb, log
from psutil._common import bytes2human
from PwnT00ls.lib.pprint import safe_print


def get_base(libs=None, elf=None, sh=None):
    """ Usage:
    text_base, libc_base = get_base(libs=sh.libs(), elf=elf)
    text_base, libc_base = get_base(sh=sh)

    if sys.version_info.major < 3:
        text_base = libs[str(args.elf.path)]
        # text_base = libs[str(sh.argv[0].strip("."))]
    """

    if not libs and not elf and not sh:
        log.warn("get_base: set sh or libs, elf")

    if elf is None:
        return get_sh_base(sh)

    try:
        _text_base = libs[elf.path]
        # _text_base = libs[str(sh.argv[0].strip(b"."), encoding="utf-8")]
    except:
        print(libs)
        log.warn("get_base: try in again!")

    for key in libs:
        if "libc" in key:
            return _text_base, libs[key]


def get_sh_base(sh):
    """ Usage:
    text_base, libc_base = get_base(sh) 
    """

    libs = sh.libs()

    if sys.version_info.major >= 3:
        _text_base = libs[str(sh.argv[0].strip(b"."), encoding="utf-8")]
    else:
        _text_base = libs[str(sh.argv[0].strip("."))]

    for key in libs:
        if "libc" in key:
            return _text_base, libs[key]


def get_core_maps(sh):
    # print(sh.corefile.maps)
    return sh.corefile.mappings


def get_heap_map(sh):
    """ Usage:
    heap_addr = int("0x" + get_heap_map(sh).addr.split("-")[0], 16) + 0x12730
    """
    p = psutil.Process(sh.pid)
    templ = "%-20s %10s  %-7s %s"
    M = p.memory_maps(grouped=False)
    for idx in range(len(M)):
        m = p.memory_maps(grouped=False)[idx]
        if m.path == "[heap]":
            safe_print(templ % (m.addr.split("-")[0].zfill(16), bytes2human(m.rss), m.perms, m.path))
            return m

    log.warn("get_heap_map: cannot get heap address.")
    return None


def print_all_map(sh):
    p = psutil.Process(sh.pid)
    templ = "%-20s %10s  %-7s %s"
    print(templ % ("Address", "RSS", "Mode", "Mapping"))
    total_rss = 0
    mem_maps = p.memory_maps(grouped=False)
    for m in mem_maps:
        total_rss += m.rss
        safe_print(templ % (m.addr.split("-")[0].zfill(16), bytes2human(m.rss), m.perms, m.path))
    print("-" * 31)
    print(templ % ("Total", bytes2human(total_rss), "", ""))
    safe_print("PID = %s, name = %s" % (p.pid, p.name()))
    return mem_maps
