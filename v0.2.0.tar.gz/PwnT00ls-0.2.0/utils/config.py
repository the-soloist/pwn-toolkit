#!/usr/bin/python3
# -*- coding:utf-8 -*-
import argparse


# init parser
parser = argparse.ArgumentParser()
parser.add_argument("-r", "--remote", action="store_true")
parser.add_argument("-l", "--local", action="store_true")
parser.add_argument("-e", "--env_or_qemu", action="store_true")
parser.add_argument("-d", "--debug", action="store_true")

# sub parser
subparsers = parser.add_subparsers(help='sub command')

# awd parser
awd_parsers = subparsers.add_parser('awd', help='awd help')
awd_parsers.add_argument('-tl', "--target_list", action="store", default=None, help='add target list')
