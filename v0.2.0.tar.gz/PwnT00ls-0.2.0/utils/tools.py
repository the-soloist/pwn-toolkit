#!/usr/bin/env python
# -*- coding: utf-8 -*-
import os
import sys
import subprocess
from pwn import log, gdb, u32, u64


""" some alias var
s = lambda data: sh.send(data)
sa = lambda delim, data: sh.sendafter(delim, data)
sl = lambda data: sh.sendline(data)
sla = lambda delim, data: sh.sendlineafter(delim, data)
r = lambda numb=0x1000: sh.recv(numb)
ru = lambda delims, drop=False: sh.recvuntil(delims, drop)
rl = lambda keepends=True: sh.recvline(keepends)

tube.s = tube.send
tube.sa = tube.sendafter
tube.sl = tube.sendline
tube.sla = tube.sendlineafter
tube.r = tube.recv
tube.ru = tube.recvuntil
tube.rl = tube.recvline
"""

# plog = lambda x: log.success('%s >> %s' % (x, hex(eval(x)))) if type(eval(x)) == int else log.success('%s >> %s' % (x, eval(x)))
paddr = lambda name, value: log.success("%s -> 0x%x" % (name, value))
pinfo = lambda *args, end=" ": log.info(("%s" % end).join([str(x) for x in args]))
psucc = lambda *args, end=" ": log.success(("%s" % end).join([str(x) for x in args]))

if sys.version_info.major == 3:
    uu32 = lambda data: u32(data.ljust(4, b"\x00"))
    uu64 = lambda data: u64(data.ljust(8, b"\x00"))
else:
    # support for python2
    uu32 = lambda data: u32(data.ljust(4, "\x00"))
    uu64 = lambda data: u64(data.ljust(8, "\x00"))


def get_base_name(_file):
    return os.path.basename(_file)


def get_func_name(_frame):
    return _frame.f_code.co_name


def kill_pid(_pid):
    cmd = "kill -9 %s" % _pid
    os.system(cmd)


def get_qemu_process_list():
    get_qemu_pid_cmd = "ps aux | grep -v grep | grep qemu | awk '{print $2}'"
    subp = subprocess.Popen(get_qemu_pid_cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    res = [x.decode() for x in subp.communicate() if x.decode()]

    if len(res) == 0:
        return None
    elif len(res) == 1:
        pid = [x for x in res[0].split('\n') if x]
        return pid
    else:
        return False


def kill_all_qemu_process():
    pid = get_qemu_process_list()

    if pid is None:
        print("kill_all_qemu_process: maybe don't have qemu process")
    elif pid is False:
        print("kill_all_qemu_process: something error")
    else:
        for p in pid:
            print("killing qemu %s" % p)
            kill_pid(p)


def one_gadget(filename):
    return list(map(int, subprocess.check_output(['one_gadget', '--raw', filename]).split(b' ')))


def download_remote_binary(sh, output, prefix, suffix):
    sh.recvuntil(prefix, drop=True)
    data = sh.recvuntil(suffix, drop=True)
    open(output, "wb").write(data)
    return data
