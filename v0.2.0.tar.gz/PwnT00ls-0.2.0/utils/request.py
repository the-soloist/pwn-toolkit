#!/usr/bin/env python
# -*- coding: utf-8 -*-
import urllib
from PwnT00ls.convert.type2xx import tryC2bytes

CRLF = b"\r\n"

# alias
urlencode = urllib.parse.quote
urldecode = urllib.parse.unquote


def urlencode2bytes(s) -> bytes:
    res = b""
    for c in s:
        res += bytes("%{:02x}".format(c), encoding="utf-8")
    return res


def dump_http_request(method, url, header: dict, data=None) -> bytes:
    dump = bytes(f"{method} {url}", encoding="utf-8") + CRLF

    for k, v in header.items():
        nk, nv = tryC2bytes(k), tryC2bytes(v)
        dump += nk + b": " + nv + CRLF

    dump += CRLF

    if data:
        dump += tryC2bytes(data)

    return dump
