#!/usr/bin/env python
# -*- coding: utf-8 -*-
from pwn import log, gdb, u32, u64


# inspired from https://github.com/pullp/pwn_framework
# usage: global BPS, GDS
BPS = list()  # breakpoints
GDS = dict()  # gdb debug symbols


def pdebug(sh, gdbscript=""):
    script_lines = list()

    for b in BPS:  # add break point list
        s = "b *{_b}".format(_b=str(b))
        script_lines.append(s)

    for k, v in GDS.items():  # add gdb debug symbols
        s = "set ${_k}={_v}".format(_k=k, _v=str(v))
        script_lines.append(s)

    script_lines.append(gdbscript)
    res = "\n".join(script_lines)

    log.info("gdbscript:\n" + res)
    gdb.attach(sh, res)
