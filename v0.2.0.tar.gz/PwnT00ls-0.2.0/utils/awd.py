#!/usr/bin/env python
# -*- coding: utf-8 -*-
from PwnT00ls.lib.predis import *


REDIS_SERVER = "127.0.0.1"
REDIS_PORT = 6379


def config_redis(redis_server="127.0.0.1", redis_port=6379):
    global REDIS_SERVER
    global REDIS_PORT

    REDIS_SERVER = redis_server
    REDIS_PORT = redis_port


def add_flag_to_redis():
    # TODO add flag to redis
    pass


def gen_target_list(target, trange: range):
    # trange: range(1, 255 + 1)
    host, port = target
    tlist = list()
    hidx = 2
    temp_host = host.split(".")

    for i in trange:
        temp_host[hidx] = str(i)
        new_host = ".".join(temp_host)
        tlist.append((new_host, port))
    return tlist


def read_target_list(args):
    content = open(args.target_list, 'r').read()
    content = [line for line in content.split("\n") if line]
    tlist = [t.split(":") for t in content]
    return tlist
