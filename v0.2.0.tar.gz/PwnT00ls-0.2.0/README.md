# PwnT00ls

封装一些常用的功能 + 收集常用的代码（有部分忘记原作者了，侵删 \_(:з」∠)\_ ）

## TODO

- [ ] 重构部分代码
- [ ] 添加 redis 模块
- [x] 自动设置 gdb 变量

## ENV

```
MacOS/Linux
python 3.8.10
pwntools 4.2.1
```

## INSTALL
```sh
cd /path/to/PwnT00ls
PT_PATH=$(dirname "$PWD")
export PYTHONPATH=$PYTHONPATH:$PT_PATH
```

## USAGE
```
In [1]: from pwn import *

In [2]: from PwnT00ls import *
```

# REFERENCE

1. https://github.com/ray-cp/pwn_debug
2. https://github.com/pullp/pwn_framework
3. ···
