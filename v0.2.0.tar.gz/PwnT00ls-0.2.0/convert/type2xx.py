#!/usr/bin/env python
# -*- coding: utf-8 -*-
from typing import Union


def tryC2bytes(value) -> Union[bytes, bytearray]:
    """ try convert to bytes """

    if type(value) == str:
        return bytes(value, encoding="utf-8")
    else:
        assert type(value) == bytes or type(value) == bytearray
        return value
