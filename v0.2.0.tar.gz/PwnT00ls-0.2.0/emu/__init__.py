try:
    from . import pqiling
except Exception as e:
    from PwnT00ls.lib.plogger import logger
    logger.log("ERROR", e)


__all__ = [x for x in globals().keys() if x != '__name__']
