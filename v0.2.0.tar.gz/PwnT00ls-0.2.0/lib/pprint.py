#!/usr/bin/env python
# -*- coding: utf-8 -*-
from psutil._compat import get_terminal_size


def safe_print(s):
    s = s[: get_terminal_size()[0]]
    try:
        print(s)
    except UnicodeEncodeError:
        print(s.encode("ascii", "ignore").decode())
