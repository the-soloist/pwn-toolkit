#!/usr/bin/env python
# -*- coding: utf-8 -*-
from pwn import p32, p64


class Rtld_Global(object):
    def __init__(self, _address, _arch=64):
        self.arch = _arch
        self.rtld_global = {}
        self.address = _address
        self.p = None
        self.pad_len = None
        self.payload = b''
        self.init()

    def __str__(self):
        pass

    def init(self):
        if self.arch == 64:
            self.p = p64
        elif self.arch == 32:
            self.p = p32
        self.pad_len = self.arch // 8

    def set(self, idx, value):
        self.rtld_global[idx] = value

    def offset(self, idx=0):
        return self.address + idx * self.pad_len

    def dump(self):
        self.payload = b''
        for key, value in self.rtld_global.items():
            if key <= 0:
                pass
            else:
                self.payload = self.payload.ljust(self.pad_len * key, b'\x00')
            self.payload += self.p(value)
        return self.payload
