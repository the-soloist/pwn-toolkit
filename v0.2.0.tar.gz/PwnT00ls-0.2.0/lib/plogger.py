#!/usr/bin/env python
# -*- coding: utf-8 -*-
# copy from https://github.com/shmilylty/OneForAll/blob/master/config/log.py
import sys
import os
from pathlib import Path
from loguru import logger

# set log path
# relative_directory = Path(__file__).parent.parent  # 代码相对路径
# result_save_dir = relative_directory.joinpath("log")  # 结果保存目录
# log_path = result_save_dir.joinpath("/tmp/log/loguru.log")  # 日志保存路径

log_path = Path("/tmp/log/PwnT00ls.log")

if not log_path.is_file():
    log_path.parent.mkdir(exist_ok=True)
    log_path.touch()

# config logger
# 终端日志输出格式
stdout_fmt = (
    "<cyan>{time:HH:mm:ss.SSS}</cyan> "
    "[<level>{level: <5}</level>] "
    "{level.icon}"
    "<blue>{module}</blue>:<cyan>{line}</cyan> - "
    "<level>{message}</level>"
)

# 日志文件记录格式
logfile_fmt = (
    "<light-green>{time:YYYY-MM-DD HH:mm:ss.SSS}</light-green> "
    "[<level>{level: <5}</level>] "
    "<cyan>{process.name}({process.id})</cyan>:"
    "<cyan>{thread.name: <18}({thread.id: <5})</cyan> | "
    "<blue>{module}</blue>.<blue>{function}</blue>:"
    "<blue>{line}</blue> - <level>{message}</level>"
)

logger.remove()
logger.level(name="TRACE", color="<cyan><bold>", icon="✏️ ")
logger.level(name="DEBUG", color="<blue><bold>", icon="🐞 ")
logger.level(name="INFOR", no=20, color="<green><bold>", icon="ℹ️ ")
logger.level(name="QUITE", no=25, color="<green><bold>", icon="🤫 ")
logger.level(name="ALERT", no=30, color="<yellow><bold>", icon="⚠️ ")
logger.level(name="ERROR", color="<red><bold>", icon="❌ ")
logger.level(name="FATAL", no=50, color="<RED><bold>", icon="☠️ ")

# 如果你想在命令终端静默运行，可以将以下一行中的 level 设置为 QUITE
logger.add(sys.stderr, level="INFOR", format=stdout_fmt, enqueue=True)  # 命令终端日志级别默认为INFOR
logger.add(log_path, level="TRACE", format=logfile_fmt, enqueue=True, encoding="utf-8")  # 日志文件默认为级别为DEBUG


if __name__ == "__main__":
    logger.log("TRACE", "TRACE TEST")
    logger.log("DEBUG", "DEBUG TEST")
    logger.log("INFOR", "INFOR TEST")
    logger.log("QUITE", "QUITE TEST")
    logger.log("ALERT", "ALERT TEST")
    logger.log("ERROR", "ERROR TEST")
    logger.log("FATAL", "FATAL TEST")
