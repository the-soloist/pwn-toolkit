# -*- coding:utf-8 -*-


# IO_FILE
def pack_file(_flags=0,
              _IO_read_ptr=0,
              _IO_read_end=0,
              _IO_read_base=0,
              _IO_write_base=0,
              _IO_write_ptr=0,
              _IO_write_end=0,
              _IO_buf_base=0,
              _IO_buf_end=0,
              _IO_save_base=0,
              _IO_backup_base=0,
              _IO_save_end=0,
              _IO_marker=0,
              _IO_chain=0,
              _fileno=0,
              _lock=0,
              _wide_data=0,
              _mode=0):
              
    file_struct = p32(_flags) + \
                  p32(0) + \
                  p64(_IO_read_ptr) + \
                  p64(_IO_read_end) + \
                  p64(_IO_read_base) + \
                  p64(_IO_write_base) + \
                  p64(_IO_write_ptr) + \
                  p64(_IO_write_end) + \
                  p64(_IO_buf_base) + \
                  p64(_IO_buf_end) + \
                  p64(_IO_save_base) + \
                  p64(_IO_backup_base) + \
                  p64(_IO_save_end) + \
                  p64(_IO_marker) + \
                  p64(_IO_chain) + \
                  p32(_fileno)
    file_struct = file_struct.ljust(0x88, b"\x00")
    file_struct += p64(_lock)
    file_struct = file_struct.ljust(0xa0, b"\x00")
    file_struct += p64(_wide_data)
    file_struct = file_struct.ljust(0xc0, b"\x00")
    file_struct += p64(_mode)
    file_struct = file_struct.ljust(0xd8, b"\x00")
    return file_struct

