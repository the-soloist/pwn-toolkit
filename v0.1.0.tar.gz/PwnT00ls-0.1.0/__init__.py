from __future__ import absolute_import
from pwn_framework.toplevel import *

pwnpwnpwn = pwn_the_world
