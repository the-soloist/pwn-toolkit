#!/bin/sh

if [ $# -lt 1 ]; then
	echo "USAGE: $0 [commit]"
	echo " e.g.: $0 update"
	exit 1
fi

COMMIT=$*
echo $COMMITl

set -x

# update requirements.txt
TMP_PYREQ_PATH="/tmp/.temp-requirements.txt"
pipreqs . --use-local --print >$TMP_PYREQ_PATH && cat $TMP_PYREQ_PATH | sort >./requirements.txt && rm $TMP_PYREQ_PATH

# push repo
git add .
git commit -m "$COMMIT"
git push
# git push origin --tags