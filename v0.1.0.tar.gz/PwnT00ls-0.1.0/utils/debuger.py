#!/usr/bin/env python
# -*- coding: utf-8 -*-
from pwn import log, gdb, u32, u64


# inspired from https://github.com/pullp/pwn_framework
# usage: global BPS, GDS
BPS = list()  # breakpoints
GDS = dict()  # gdb debug symbols


def pdebug(sh, script):
    slist = list()

    for b in BPS:  # get break point list
        s = "b *{_b}".format(_b=str(b))
        slist.append(s)

    for k, v in GDS.items():  # get gdb debug symbols
        s = "set ${_k}={_v}".format(_k=k, _v=str(v))
        slist.append(s)

    slist.append(script)
    _script = "\n".join(slist)

    log.info(_script)
    gdb.attach(sh, _script)
