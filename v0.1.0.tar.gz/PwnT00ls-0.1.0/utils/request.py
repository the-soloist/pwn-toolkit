#!/usr/bin/env python
# -*- coding: utf-8 -*-
import urllib
from typing import Union


CRLF = b"\r\n"


def str2bytes(value) -> Union[bytes, bytearray]:
    if type(value) == str:
        return bytes(value, encoding="utf-8")
    else:
        assert type(value) == bytes or type(value) == bytearray
        return value


def dump_request(method, uri, header: dict, data=None) -> bytes:
    dump = bytes(f"{method} {uri}", encoding="utf-8") + CRLF

    # example:
    #   b"Login-ID: admin\r\n"
    for k, v in header.items():
        nk, nv = str2bytes(k), str2bytes(v)
        dump += nk + b": " + nv + CRLF

    dump += CRLF

    if data:
        dump += str2bytes(data)

    return dump


def urlencodebytes(s) -> bytes:
    res = b""
    for c in s:
        res += bytes("%{:02x}".format(c), encoding="utf-8")
    return res


# alias
urlencode = urllib.parse.quote
urldecode = urllib.parse.unquote
