#!/usr/bin/env python
# -*- coding: utf-8 -*-

from pwn_framework.lib.predis import *


REDIS_SERVER = "127.0.0.1"
REDIS_PORT = 6379


def config_redis(_redis_server="127.0.0.1", _redis_port=6379):
    global REDIS_SERVER
    global REDIS_PORT

    REDIS_SERVER = _redis_server
    REDIS_PORT = _redis_port


def add_flag_to_redis():
    pass


def gen_target_list(target, trange: range):
    # trange: range(1, 255 + 1)
    host, port = target
    tlist = list()
    hidx = 2
    temp_host = host.split(".")

    for i in trange:
        temp_host[hidx] = str(i)
        new_host = ".".join(temp_host)
        tlist.append((new_host, port))
    return tlist


def read_target_list(args):
    content = open(args.target_list, 'r').read()
    content = [line for line in content.split("\n") if line]
    tlist = [t.split(":") for t in content]
    return tlist
