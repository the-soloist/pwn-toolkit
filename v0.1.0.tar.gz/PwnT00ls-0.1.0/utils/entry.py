#!/usr/bin/env python
# -*- coding: utf-8 -*-
from pwn import process, remote, gdb


def delete_unexpected_keyword(arg, klist):
    # delete unexpected keyword argument
    for k in klist:
        try:
            arg.pop(k)
        except:
            pass


def pwn_the_world(args):
    if args.remote:
        host, port = args.target
        sh = remote(host, port)

    elif args.local:
        sh = process(args.binary.path)

    elif args.env_or_qemu:
        """ Qemu mode usage:
        >>> sh = process([ld.path, binary.path], env={"LD_PRELOAD": libc.path})
        >>> sh = process([f"qemu-{context.arch}", "-g", "9999", "-L", ".", binary.path])

        >>> args.cmd = [ld.path, binary.path]
        >>> args.kwargs = {
                "env": {"LD_PRELOAD": "/path/to/libc.so"},  # libc.path
            }

        >>> args.cmd = [
                f"qemu-{context.arch}", 
                "-g", "9999", 
                "-L", ".", binary.path
            ]

        >>> args.cmd = "./run.sh"

        >>> sh = pwnpwnpwn(args)
        """

        assert "cmd" in args
        if args.cmd is None:
            print("read usage first (in utils/config.c#L14)")
            exit()

        eq_black_list = ["gdbscript"]
        delete_unexpected_keyword(args.kwargs, eq_black_list)

        sh = process(args.cmd, **args.kwargs)

    elif args.debug:
        """ Debug mode usage:
        >>> args.kwargs = { 
                "gdbscript": GDB_SCRIPT, 
            }
        >>> sh = pwn_the_world(args)
        """

        dbg_black_list = ["env"]
        delete_unexpected_keyword(args.kwargs, dbg_black_list)

        sh = gdb.debug(args.binary.path, **args.kwargs)

    else:
        from pwn_framework.utils.config import parser
        parser.print_help()
        exit(0)

    return sh
